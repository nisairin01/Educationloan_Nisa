package com.project.data;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EducationLoanProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
