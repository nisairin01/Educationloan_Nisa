package com.project.data.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="document")
public class DocumentModel {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int documentId;
	String documentName;
	String documenttype;
	@Lob
	byte[] documentupload;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="loan_id")
	private LoanApplicantModel loan;
	
	public DocumentModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public DocumentModel(int documentId, String documentName, String documenttype, byte[] documentupload) {
		super();
		this.documentId = documentId;
		this.documentName = documentName;
		this.documenttype = documenttype;
		this.documentupload = documentupload;
	}

	public int getDocumentId() {
		return documentId;
	}
	public void setDocumentId(int documentId) {
		this.documentId = documentId;
	}
	public String getDocumenttype() {
		return documenttype;
	}
	public void setDocumenttype(String documenttype) {
		this.documenttype = documenttype;
	}
	public byte[] getDocumentupload() {
		return documentupload;
	}
	public void setDocumentupload(byte[] documentupload) {
		this.documentupload = documentupload;
	}

	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public LoanApplicantModel getLoan() {
		return loan;
	}

	public void setLoan(LoanApplicantModel loan) {
		this.loan = loan;
	}
}
