package com.project.data.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.data.model.LoanApplicantModel;
import com.project.data.service.LoanService;



@RestController
@RequestMapping("/loan")
@CrossOrigin(origins="http://localhost:4200")
public class LoanController {
	@Autowired
	private LoanService loanservice;
	
	@PostMapping("/addLoan")
	public ResponseEntity<LoanApplicantModel> addLoan(@RequestBody LoanApplicantModel data) {
		return ResponseEntity.status(HttpStatus.CREATED).body(this.loanservice.addLoan(data));
	}
	
	
	@GetMapping("/viewloan/{id}")
	public ResponseEntity<LoanApplicantModel> getLoan(@PathVariable("id") int loanId) {
		return ResponseEntity.status(HttpStatus.OK).body(this.loanservice.getLoan(loanId));
	}
	
	@PutMapping("/editLoan/{loanId}")
	public ResponseEntity<LoanApplicantModel> editloan(@PathVariable("loanId") int id,@RequestBody LoanApplicantModel lmodel) {
		return ResponseEntity.status(HttpStatus.OK).body(this.loanservice.editLoan(id, lmodel));
	}
	
	@DeleteMapping("/delete/{loanid}")
	ResponseEntity<?> deleteloan(@PathVariable("loanid") long loanId) {
		if(this.loanservice.deleteLoan(loanId)) {
			return ResponseEntity.status(HttpStatus.OK).body("Success");
		}
		else {
			return ResponseEntity.status(HttpStatus.OK).body("Failure");
		}
	}
	
	@GetMapping("/viewLoan")
	public List<LoanApplicantModel> viewLoan() {
		return this.loanservice.viewLoans();
	}
	
	@GetMapping("/approveloan/{id}")
	public String approveLoan(@PathVariable("id") long loanId) {
		return this.loanservice.approveLoan(loanId);
	}
	
	@GetMapping("/rejectloan/{id}")
	public String rejectLoan(@PathVariable("id") long loanId) {
		return this.loanservice.rejectLoan(loanId);
	}
}
