package com.project.data.exceptions;

public class LoanNotAllowedException extends Exception{
	
	public LoanNotAllowedException(String msg) {
		super(msg);
	}
}
