package com.project.data.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.data.model.UserModel;
import com.project.data.repository.Userrepo;

@Service
public class Userservice {
	@Autowired
	private Userrepo userrepo;

	public UserModel addUser(UserModel data) {
		if (this.userrepo.existsById(data.getEmail())){
			return null;
		} else
			return this.userrepo.save(data);
	}

	public UserModel getUser(String Userid) {
		return this.userrepo.findById(Userid).get();
	}

	public UserModel editUser(String email,UserModel data) {
		UserModel udata = this.userrepo.findById(email).get();
		if (this.userrepo.existsById(email)) {
			UserModel updatedData = udata;
			updatedData.setUsername(udata.getUsername());
			updatedData.setMobileNumber(udata.getMobileNumber());
			updatedData.setPassword(udata.getPassword());
			updatedData.setUserRole(udata.getUserRole());
			return this.userrepo.save(updatedData);
		}
		else
			return null;
	}

	public void deleteUser(String email) {
		this.userrepo.deleteById(email);
	}

	
	public UserModel login(String email, String password) {
		UserModel user=userrepo.findByEmailAndPassword(email, password);
		if(user==null||!user.getPassword().equals(password)) {
		return null; //invalid email or password
		}
		return user;
	}
		public UserModel signUp(UserModel userModel) {
		UserModel u=userrepo.findByEmail(userModel.getEmail());
		if(u==null || !u.getPassword().equals(u.getPassword())) {
		return null; //user with this email already exists
		}
		return userrepo.save(userModel);
	}
		
}



//public ResponseEntity<?> login(UserModel user) {
//UserModel u = userrepo.findByEmailAndPassword(user.getEmail(), user.getPassword());
//if (u != null) {
//	return ResponseEntity.ok().body(u.getUserId());
//}			
//else {
//		return (ResponseEntity<?>) ResponseEntity.notFound();
//	}
//}
//public boolean signup(UserModel userModel) {
//UserModel uu = userrepo.findByEmailAndPassword(userModel.getEmail(), userModel.getPassword());
//if (uu != null) {
//	if (uu.getUserRole().equals("Admin")) {
//		return true;
//	}
//	else {
//		return false;
//	}
//} 
//else {
//	return false;
//}