package com.project.data.exceptions;

public class UserNotfound extends Exception{
	public UserNotfound(String msg) {
		super(msg);
	}
}
