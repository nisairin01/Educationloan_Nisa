package com.project.data.model;

public class Comment {

}
