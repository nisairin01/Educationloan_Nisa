package com.project.data.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.data.model.LoanApplicantModel;
import com.project.data.repository.LoanRepo;

@Service
public class LoanService {
	@Autowired
	private LoanRepo loanrepo;
	
	public LoanApplicantModel addLoan(LoanApplicantModel data) {
			return this.loanrepo.save(data);
	}
	
	public List<LoanApplicantModel> viewLoans(){
		return this.loanrepo.findAll();
	}
	
	public LoanApplicantModel getLoan(long loanId) {
		return this.loanrepo.findById(loanId).get();
	}
	
	public LoanApplicantModel editLoan(long loanId,LoanApplicantModel lam) {
		if(this.loanrepo.existsById(loanId)) {
			LoanApplicantModel lm = this.loanrepo.findById(loanId).get();
			return this.loanrepo.save(lam);
		}
		else
			return null;
	}
	
	public boolean deleteLoan(long loanId) {
			 if(this.loanrepo.existsById(loanId)) {
				 this.loanrepo.deleteById(loanId);
				 return true;
			 }
			 else {
				 return false;
			 }
	}
	
	public double repaymentSchedule(long loanid) {
		double interest = 5/(4*100);
		LoanApplicantModel lm = loanrepo.findById(loanid).get();
		double principal = Double.parseDouble(lm.getLoanAmountRequired());
		int paymentTime= 5*4;
		double monthlyPayment = (principal*interest*Math.pow(1+interest,paymentTime)/(Math.pow(1+interest,paymentTime)-1));
		return monthlyPayment;
	}
	
	public String approveLoan(long loanid) {
		LoanApplicantModel newLoan = this.loanrepo.findById(loanid).get();
		newLoan.setLoanStatus("Approved");
		LoanApplicantModel upLoan = this.loanrepo.save(newLoan);
		return upLoan.getLoanStatus();
	}
	public String rejectLoan(long loanid) {
		LoanApplicantModel newLoan = this.loanrepo.findById(loanid).get();
		newLoan.setLoanStatus("Rejected");
		LoanApplicantModel upLoan = this.loanrepo.save(newLoan);
		return upLoan.getLoanStatus();
	}
}
