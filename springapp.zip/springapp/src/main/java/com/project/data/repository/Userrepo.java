package com.project.data.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.project.data.model.UserModel;

@Repository
public interface Userrepo extends JpaRepository<UserModel, String> {
	@Query("select u from UserModel u where email=:email and password=:password")
	UserModel findByEmailAndPassword(@Param("email") String email,@Param("password") String password);
	public void deleteByEmail(String email);
	public UserModel findByEmail(String email);
	public boolean findByEmail(boolean email);
}
