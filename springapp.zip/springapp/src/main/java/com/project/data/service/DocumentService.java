package com.project.data.service;

import java.io.IOException;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.project.data.model.DocumentModel;
import com.project.data.model.LoanApplicantModel;
import com.project.data.repository.DocumentRepo;
import com.project.data.repository.LoanRepo;

@Service
public class DocumentService {
	@Autowired
	private DocumentRepo docrepo;
	@Autowired
	private LoanRepo loanrepo;
	
	public DocumentModel saveDocument(MultipartFile file,Long loanid) throws IOException{
		String fileName = StringUtils.cleanPath(file.getOriginalFilename());
		String fileType = file.getContentType();
		byte[] fileData = file.getBytes();
		DocumentModel nfile = new DocumentModel();
		nfile.setDocumentName(fileName);
		nfile.setDocumenttype(fileType);
		nfile.setDocumentupload(fileData);
		LoanApplicantModel lm = loanrepo.findById(loanid).get();
		nfile.setLoan(lm);
		return docrepo.save(nfile);
	}
	
	public List<DocumentModel> viewDocument(){
		return this.docrepo.findAll();
	}
	
	public DocumentModel ViewDocById(int id) {
		return this.docrepo.findById(id).get();
	}
}
