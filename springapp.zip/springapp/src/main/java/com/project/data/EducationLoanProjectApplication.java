package com.project.data;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EducationLoanProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(EducationLoanProjectApplication.class, args);
	}

}
