package com.project.data.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
//import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.data.model.UserModel;
import com.project.data.service.Userservice;

@RestController
@RequestMapping("/user")
@CrossOrigin(origins="http://localhost:4200")
public class UserController {
	@Autowired
	private Userservice userservice;
	
	@PostMapping("/addUser")
	public ResponseEntity<UserModel> addUser(@RequestBody UserModel  data) {
		return ResponseEntity.ok().body(this.userservice.addUser(data));
	}
	
	@GetMapping("/getUser/{id}")
	public ResponseEntity<UserModel> getUser(@PathVariable("id") String id) {
		return ResponseEntity.ok().body(this.userservice.getUser(id));
	}
	
	@PutMapping("/editUser/{id}")
	public ResponseEntity<UserModel> editUser(@PathVariable("id") String id,@RequestBody UserModel data) {
		return new ResponseEntity<>(this.userservice.editUser(id, data),HttpStatus.OK);
	}
	
	@DeleteMapping("/delete/{id}")
	public void deleteUser(@PathVariable("id") String id) {
		this.userservice.deleteUser(id);
	}
	
	@PostMapping("/login")
	public ResponseEntity<UserModel> signin(@RequestBody UserModel user) {
		UserModel loginuser=userservice.login(user.getEmail(),user.getPassword());
		if(loginuser==null) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build(); //invalid email or password
		}
		return ResponseEntity.status(HttpStatus.OK).body(loginuser);
	}
	@PostMapping("/signup/user")
	public ResponseEntity<UserModel> signupUser(@RequestBody UserModel userModel) {
		UserModel newuser=userservice.signUp(userModel);
		if(newuser==null) {
			return ResponseEntity.badRequest().build(); //email already exists
		}
		return ResponseEntity.status(HttpStatus.CREATED).body(newuser);
	}
	//public ResponseEntity<?> checklogin(@)
}
